Taken from 

https://github.com/facelessuser/soupsieve/tree/main


